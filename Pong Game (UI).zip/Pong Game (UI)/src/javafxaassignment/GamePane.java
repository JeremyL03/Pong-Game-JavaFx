package javafxaassignment;

import javafx.animation.AnimationTimer;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import static javafx.scene.input.KeyCode.DOWN;
import static javafx.scene.input.KeyCode.S;
import static javafx.scene.input.KeyCode.UP;
import static javafx.scene.input.KeyCode.W;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class GamePane extends Pane {                         // game dimensions and paddle/ball sizes
    static final int GAME_WIDTH = 1000;
    static final int GAME_HEIGHT = (int) (GAME_WIDTH * 0.5555);
    static final int BALL_DIAMETER = 20;
    static final int PADDLE_WIDTH = 25;
    static final int PADDLE_HEIGHT = 100;

    Paddle paddle1;                                           // Game components
    Paddle paddle2;
    Ball ball;
    Score score;
    Label gameOverLabel;
    Button pauseButton;
    Button exitButton;
    Button settingsButton;

    boolean isGameOver;                                          // Game state flags
    boolean isPaused;

    AnimationTimer gameLoop;                                     // Animation timer for the game loop

    public GamePane() {                                          // Constructor

        setPrefSize(GAME_WIDTH, GAME_HEIGHT);
        setStyle("-fx-background-color: black;");


        newPaddles();
        newBall();
        score = new Score(GAME_WIDTH, GAME_HEIGHT);
        getChildren().addAll(paddle1, paddle2, ball, score);
        score.draw();

        gameOverLabel = new Label();                              // game over label
        gameOverLabel.setTextFill(Color.WHITE);
        gameOverLabel.setFont(new Font("Consolas", 30));     // Smaller font size
        gameOverLabel.setVisible(false);
        getChildren().add(gameOverLabel);

        pauseButton = new Button("Pause");
        pauseButton.setLayoutX(GAME_WIDTH - 100);
        pauseButton.setLayoutY(20);
        pauseButton.setOnAction(e -> togglePause());
        getChildren().add(pauseButton);

        exitButton = new Button("Exit");
        exitButton.setLayoutX(GAME_WIDTH - 200);
        exitButton.setLayoutY(20);
        exitButton.setOnAction(e -> exitGame());
        getChildren().add(exitButton);

        settingsButton = new Button("Settings");
        settingsButton.setLayoutX(20);
        settingsButton.setLayoutY(20);
        getChildren().add(settingsButton);

        gameLoop = new AnimationTimer() {                        // Initialize and start game loop
            private long lastUpdate = 0;

            @Override
            public void handle(long now) {
                // Update game state if the game is not over or paused, roughly 60 FPS
                if (!isGameOver && !isPaused && now - lastUpdate >= 16_000_000) {
                    move();
                    checkCollision();
                    score.draw();
                    lastUpdate = now;
                }
            }
        };

        gameLoop.start();

        setFocusTraversable(true);                               // Set up key event handling for paddle movement
        setOnKeyPressed(e -> handleKeyPressed(e.getCode()));
        setOnKeyReleased(e -> handleKeyReleased(e.getCode()));
        requestFocus();                                          // Ensure the GamePane has focus to capture key events
    }
                                                                 // Handle key pressed events for paddle movement
    private void handleKeyPressed(KeyCode code) {
    if (!isPaused) {
        switch (code) {
            case W:
                paddle1.setYDirection(-20); // Move paddle1 up
                break;
            case S:
                paddle1.setYDirection(20);  // Move paddle1 down
                break;
            case UP:
                paddle2.setYDirection(-20); // Move paddle2 up
                break;
            case DOWN:
                paddle2.setYDirection(20); // Move paddle2 down
                break;
            default:
                break;
        }
    }
}

private void handleKeyReleased(KeyCode code) {
    if (!isPaused) {
        switch (code) {
            case W:
            case S:
                paddle1.setYDirection(0); // Stop paddle1
                break;
            case UP:
            case DOWN:
                paddle2.setYDirection(0); // Stop paddle2
                break;
            default:
                break;
        }
    }
}
                                                                // Initialize a ball in center game center area
    public void newBall() {
        ball = new Ball((GAME_WIDTH / 2) - (BALL_DIAMETER / 2), (GAME_HEIGHT / 2) - (BALL_DIAMETER / 2), BALL_DIAMETER, BALL_DIAMETER);
    }
                                                               // Initialize paddles at starting positions
    public void newPaddles() {
        paddle1 = new Paddle(0, (GAME_HEIGHT / 2) - (PADDLE_HEIGHT / 2), PADDLE_WIDTH, PADDLE_HEIGHT, 1);
        paddle2 = new Paddle(GAME_WIDTH - PADDLE_WIDTH, (GAME_HEIGHT / 2) - (PADDLE_HEIGHT / 2), PADDLE_WIDTH, PADDLE_HEIGHT, 2);
    }

    public void move() {
        paddle1.move();
        paddle2.move();
        ball.move();
    }
                                                                    // Check collisions and update game state
    public void checkCollision() {
        double ballCenterY = ball.getCenterY();
        double gameHeightMinusBallDiameter = GAME_HEIGHT - BALL_DIAMETER;
                                                                    // collision with top and bottom walls
        if (ballCenterY <= 0 || ballCenterY >= gameHeightMinusBallDiameter) {
            ball.setYDirection(-ball.yVelocity);
        }

                                                                    // collision with paddles
        if (ball.getBoundsInParent().intersects(paddle1.getBoundsInParent()) ||
                ball.getBoundsInParent().intersects(paddle2.getBoundsInParent())) {

            boolean isPaddle1 = ball.getBoundsInParent().intersects(paddle1.getBoundsInParent());
            ball.setXDirection(isPaddle1 ? Math.abs(ball.xVelocity) : -Math.abs(ball.xVelocity));

                                                                   // speed increase
            ball.setXDirection(Math.min(Math.abs(ball.xVelocity) + 1, 10) * (isPaddle1 ? 1 : -1));
            ball.setYDirection(ball.yVelocity > 0 ?
                    Math.min(ball.yVelocity + 1, 10) :
                    Math.max(ball.yVelocity - 1, -10));
        }
                                                                   // Scoring
        double ballCenterX = ball.getCenterX();
        if (ballCenterX <= 0) {
            score.player2++;
            resetGame();                                           // Reset game after player 2 scores
        } else if (ballCenterX >= GAME_WIDTH - BALL_DIAMETER) {
            score.player1++;
            resetGame();                                           // Reset game after player 1 scores
        }
                                                                   // Check for game over
        if (score.player1 >= 10 || score.player2 >= 10) {
            endGame();
        }
                                                                   // Ensure paddles stay within game boundaries
        paddle1.setY(Math.max(0, Math.min(paddle1.getY(), GAME_HEIGHT - PADDLE_HEIGHT)));
        paddle2.setY(Math.max(0, Math.min(paddle2.getY(), GAME_HEIGHT - PADDLE_HEIGHT)));
    }
                                                                  // End game and display the game over
    private void endGame() {
        isGameOver = true;
        gameOverLabel.setText("Game Over! " + (score.player1 >= 10 ? "Player 1" : "Player 2") + " Wins!");
        gameOverLabel.setVisible(true);
        gameOverLabel.setLayoutX((GAME_WIDTH - gameOverLabel.getWidth()) / 2);
        gameOverLabel.setLayoutY((GAME_HEIGHT - gameOverLabel.getHeight()) / 2);
    }
                                                                 // Reset game state without ending the game
    private void resetGame() {
        if (!isGameOver) {
            getChildren().removeAll(ball, paddle1, paddle2);
            newBall();
            newPaddles();
            getChildren().addAll(paddle1, paddle2, ball);
        }
    }
                                                                 // Toggle game pause/resume
    void togglePause() {
        isPaused = !isPaused;
        pauseButton.setText(isPaused ? "Resume" : "Pause");
        requestFocus(); // Ensure the GamePane has focus to capture key events
        if (!isPaused) {
            setOnKeyPressed(e -> handleKeyPressed(e.getCode()));
            setOnKeyReleased(e -> handleKeyReleased(e.getCode()));
        }
    }
                                                               // Exit game
    void exitGame() {
        Stage stage = (Stage) getScene().getWindow();
        stage.close();
    }
}