/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML.java to edit this template
 */
package javafxaassignment;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;
import java.io.IOException;
import javafx.scene.Node;
import static javafx.scene.input.KeyCode.ESCAPE;
/**
 *
 * @author hobot
 */
public class JavaFXAassignment extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        
        
        
       stage.setOnCloseRequest(event -> 
       {
           event.consume();
           xbtn(stage);
       }
       );
       
    }
    private void xbtn(Stage stage) 
    {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("DIEEE");
        alert.setHeaderText("You're about to die!");
        alert.setContentText("Do you want to die before saving?:");
        
        if(alert.showAndWait().get()== ButtonType.OK)
        {
        stage.close();
        }
     }
   
    
    public static void main(String[] args) {
        launch(args);
    }
    
}
