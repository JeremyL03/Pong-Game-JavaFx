package javafxaassignment;

import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class Ball extends Circle {
    int xVelocity;
    int yVelocity;
    int initialSpeed = 2;                  // Initial speed of the ball

    // Constructor
    public Ball(double x, double y, double width, double height) {
        super(x, y, width / 2, Color.WHITE);                   // Circle with position, radius, and color
        int randomXDirection = Math.random() < 0.5 ? -1 : 1;      // The initial x direction randomly
        setXDirection(randomXDirection * initialSpeed);           // x velocity
        int randomYDirection = Math.random() < 0.5 ? -1 : 1;      // The initial y direction randomly
        setYDirection(randomYDirection * initialSpeed);           // y velocity
    }

    // Set the x direction velocity
    public void setXDirection(int randomXDirection) {
        xVelocity = randomXDirection;
    }

    // Set the y direction velocity
    public void setYDirection(int randomYDirection) {
        yVelocity = randomYDirection;
    }

    // Move the ball based on its velocity
    public void move() {
        setCenterX(getCenterX() + xVelocity); // Update the x position of the ball
        setCenterY(getCenterY() + yVelocity); // Update the y position of the ball
}
}