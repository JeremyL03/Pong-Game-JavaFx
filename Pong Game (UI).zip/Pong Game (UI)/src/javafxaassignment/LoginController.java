package javafxaassignment;

import java.net.URL;
import javafx.scene.Node;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


public class LoginController implements Initializable {

    @FXML
    private TextField username;
    @FXML
    private PasswordField password;
    @FXML
    private Button login;
    @FXML
    private Label wronglogin;
    @FXML
    private Button backlogin;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    
            
    @FXML
    private void userlogin(ActionEvent event) throws Exception{
        
        if(username.getText().equals("zora") && password.getText().equals("123")) {
            
            wronglogin.setText("Success");
            
        Parent root = FXMLLoader.load(getClass().getResource("MainMenuLogin.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
        }
        
    if(username.getText().equals("Jen") && password.getText().equals("456")) {
            
            wronglogin.setText("Success");
            
        Parent root = FXMLLoader.load(getClass().getResource("MainMenuLogin.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
        
        }
   
    else if(username.getText().isEmpty() && password.getText().isEmpty()) {
        wronglogin.setText("Please Enter your credentials.");
    }
    
    else{
    wronglogin.setText("Wrong Credentials");
    
}
}

    @FXML
    private void backlogin(ActionEvent event) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
}
