package javafxaassignment;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class PauseMenuController1 {

    private Stage stage;
    private Scene mainMenuScene;
    private Scene settingsScene;
  
    @FXML
    private Button resume;
    @FXML
    private Button restart;
    @FXML
    private Button mainmenu;
    @FXML
    private Button settings;

    @FXML
    private void handleResume(ActionEvent event) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("Game_1.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void handleRestart(ActionEvent event) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("Game_1.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }


    @FXML
    private void handleSettings(ActionEvent event) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("settings_5.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void handleMainMenu(ActionEvent event) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("MainMenu.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
}
