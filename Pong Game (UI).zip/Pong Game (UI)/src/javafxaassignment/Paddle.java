package javafxaassignment;

import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class Paddle extends Rectangle {
    int id;                                    // Identifier for the paddle (1 for player 1, 2 for player 2)
    int yVelocity;                             // Vertical velocity to paddle

    // Constructor
    public Paddle(double x, double y, double width, double height, int id) {
        super(x, y, width, height);                   // Rectangle position and size
        this.id = id;
        setFill(id == 1 ? Color.ANTIQUEWHITE : Color.FLORALWHITE);
    }

    public void setYDirection(int yDirection) {      // Set vertical direction of paddle
        yVelocity = yDirection;
    }

    public int getYVelocity() {                      // Get current vertical velocity of paddle
        return yVelocity;
    }

    public void move() {
        setY(getY() + yVelocity);
    } // Move paddle based on its vertical velocity
}
