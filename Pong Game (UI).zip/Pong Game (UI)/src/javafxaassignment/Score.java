package javafxaassignment;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class Score extends Canvas {
    static int GAME_WIDTH;
    static int GAME_HEIGHT;

    int player1;
    int player2;

    // Constructor
    public Score(int GAME_WIDTH, int GAME_HEIGHT) {
        super(GAME_WIDTH, 100);                           // Initialize canvas with game width and height
        Score.GAME_WIDTH = GAME_WIDTH;
        Score.GAME_HEIGHT = GAME_HEIGHT;
    }

    // Draw the scores and center line
    public void draw() {
        GraphicsContext gc = getGraphicsContext2D();
        gc.clearRect(0, 0, getWidth(), getHeight());   // Clear previous drawings
        gc.setFill(Color.WHITE);
        gc.setFont(new Font("Consolas", 50));           // Set scores font

        gc.fillText(String.format("%02d", player1), (GAME_WIDTH / 2) - 85, 50);         // player 1's score on the left side
        gc.fillText(String.format("%02d", player2), (GAME_WIDTH / 2) + 20, 50);         // player 2's score on the right side

        // center line
        gc.strokeLine(GAME_WIDTH / 2, 0, GAME_WIDTH / 2, GAME_HEIGHT);
    }
}
