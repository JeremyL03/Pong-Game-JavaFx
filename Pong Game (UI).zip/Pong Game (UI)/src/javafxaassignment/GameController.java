package javafxaassignment;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.animation.AnimationTimer;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;


public class GameController implements Initializable {

    @FXML
    private Pane gamePane;
    @FXML
    private Button pauseButton;
    @FXML
    private Button exitButton;
    @FXML
    private Button settingsButton;

    private GamePane customGamePane;
    private Paddle paddle1;
    private Paddle paddle2;
    private Ball ball;
    private Score score;
    private Label gameOverLabel;

    private boolean isGameOver = false;
    private boolean isPaused = false;
    
    private AnimationTimer gameLoop;
    @FXML
    private Button gameresult;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    public void initialize() {
        gamePane.setPrefSize(GamePane.GAME_WIDTH, GamePane.GAME_HEIGHT);
        gamePane.setStyle("-fx-background-color: black;");

        newPaddles();
        newBall();
        score = new Score(GamePane.GAME_WIDTH, GamePane.GAME_HEIGHT);
        gamePane.getChildren().addAll(paddle1, paddle2, ball, score);
        score.draw();

        gameOverLabel = new Label();
        gameOverLabel.setTextFill(Color.WHITE);
        gameOverLabel.setFont(new Font("Consolas", 30)); 
        gameOverLabel.setVisible(false);
        gamePane.getChildren().add(gameOverLabel);

        pauseButton.setOnAction(e -> togglePause());
        exitButton.setOnAction(e -> exitGame());

        gameLoop = new AnimationTimer() {
            private long lastUpdate = 0;

            @Override
            public void handle(long now) {
                if (!isGameOver && !isPaused && now - lastUpdate >= 16_000_000) {
                    move();
                    checkCollision();
                    score.draw();
                    lastUpdate = now;
                }
            }
        };

        gameLoop.start();

        gamePane.setFocusTraversable(true);
        gamePane.setOnKeyPressed(e -> handleKeyPressed(e.getCode()));
        gamePane.setOnKeyReleased(e -> handleKeyReleased(e.getCode()));
        gamePane.requestFocus();
    }

    private void handleKeyPressed(KeyCode code) {
        if (!isPaused) {
            switch (code) {
                case W:
                    paddle1.setYDirection(-20);
                    break;
                case S:
                    paddle1.setYDirection(20);
                    break;
                case UP:
                    paddle2.setYDirection(-20);
                    break;
                case DOWN:
                    paddle2.setYDirection(20);
                    break;
                default:
                    break;
            }
        }
    }

    private void handleKeyReleased(KeyCode code) {
        if (!isPaused) {
            switch (code) {
                case W:
                case S:
                    paddle1.setYDirection(0);
                    break;
                case UP:
                case DOWN:
                    paddle2.setYDirection(0);
                    break;
                default:
                    break;
            }
        }
    }

    private void newBall() {
        ball = new Ball((GamePane.GAME_WIDTH / 2) - (GamePane.BALL_DIAMETER / 2), 
                        (GamePane.GAME_HEIGHT / 2) - (GamePane.BALL_DIAMETER / 2), 
                        GamePane.BALL_DIAMETER, GamePane.BALL_DIAMETER);
    }

    private void newPaddles() {
        paddle1 = new Paddle(0, (GamePane.GAME_HEIGHT / 2) - (GamePane.PADDLE_HEIGHT / 2), 
                             GamePane.PADDLE_WIDTH, GamePane.PADDLE_HEIGHT, 1);
        paddle2 = new Paddle(GamePane.GAME_WIDTH - GamePane.PADDLE_WIDTH, 
                             (GamePane.GAME_HEIGHT / 2) - (GamePane.PADDLE_HEIGHT / 2), 
                             GamePane.PADDLE_WIDTH, GamePane.PADDLE_HEIGHT, 2);
    }

    private void move() {
        paddle1.move();
        paddle2.move();
        ball.move();
    }

    private void checkCollision() {
        double ballCenterY = ball.getCenterY();
        double gameHeightMinusBallDiameter = GamePane.GAME_HEIGHT - GamePane.BALL_DIAMETER;

        if (ballCenterY <= 0 || ballCenterY >= gameHeightMinusBallDiameter) {
            ball.setYDirection(-ball.yVelocity);
        }

        if (ball.getBoundsInParent().intersects(paddle1.getBoundsInParent()) ||
                ball.getBoundsInParent().intersects(paddle2.getBoundsInParent())) {

            boolean isPaddle1 = ball.getBoundsInParent().intersects(paddle1.getBoundsInParent());
            ball.setXDirection(isPaddle1 ? Math.abs(ball.xVelocity) : -Math.abs(ball.xVelocity));

            ball.setXDirection(Math.min(Math.abs(ball.xVelocity) + 1, 10) * (isPaddle1 ? 1 : -1));
            ball.setYDirection(ball.yVelocity > 0 ?
                    Math.min(ball.yVelocity + 1, 10) :
                    Math.max(ball.yVelocity - 1, -10));
        }

        double ballCenterX = ball.getCenterX();
        if (ballCenterX <= 0) {
            score.player2++;
            resetGame();
        } else if (ballCenterX >= GamePane.GAME_WIDTH - GamePane.BALL_DIAMETER) {
            score.player1++;
            resetGame();
        }

        if (score.player1 >= 10 || score.player2 >= 10) {
            endGame();
        }

        paddle1.setY(Math.max(0, Math.min(paddle1.getY(), GamePane.GAME_HEIGHT - GamePane.PADDLE_HEIGHT)));
        paddle2.setY(Math.max(0, Math.min(paddle2.getY(), GamePane.GAME_HEIGHT - GamePane.PADDLE_HEIGHT)));
    }

    private void endGame() {
        isGameOver = true;
        gameOverLabel.setText("Game Over! " + (score.player1 >= 10 ? "Player 1" : "Player 2") + " Wins!");
        gameOverLabel.setVisible(true);
        gameOverLabel.setLayoutX((GamePane.GAME_WIDTH - gameOverLabel.getWidth()) / 2);
        gameOverLabel.setLayoutY((GamePane.GAME_HEIGHT - gameOverLabel.getHeight()) / 2);
    }

    private void resetGame() {
        if (!isGameOver) {
            gamePane.getChildren().removeAll(ball, paddle1, paddle2);
            newBall();
            newPaddles();
            gamePane.getChildren().addAll(paddle1, paddle2, ball);
        }
    }

    private void togglePause() {
        isPaused = !isPaused;
        pauseButton.setText(isPaused ? "Resume" : "Pause");
        gamePane.requestFocus();
    }

    private void exitGame() {
        Stage stage = (Stage) gamePane.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void handlePause(ActionEvent event) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("pausemenu.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void handleExit(ActionEvent event) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("MainMenuLogin.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void handleSettings(ActionEvent event) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("settings_2.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void handleResult(ActionEvent event) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("Results.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
}
