package javafxaassignment;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;

public class HowToPlayController {
    @FXML
    private TextArea instructionsTextArea;


    private Stage stage;
    @FXML
    private Button backhtp;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    private void initialize() {
        loadInstructions();
    }

    private void loadInstructions() {
        String filePath = "/demo/main/instructions.txt";
        StringBuilder instructions = new StringBuilder();

        try (InputStream inputStream = getClass().getResourceAsStream(filePath);
             BufferedReader br = new BufferedReader(new InputStreamReader(inputStream))) {
            String line;
            while ((line = br.readLine()) != null) {
                instructions.append(line).append("\n");
            }
        } catch (IOException e) {
            instructions.append("Error loading instructions.");
        }

        instructionsTextArea.setText(instructions.toString());
    }

    private void handleBack() {
        stage.close();
    }

    @FXML
    private void backhtps(ActionEvent event) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("MainMenuLogin.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
    }
}
