package javafxaassignment;

import javafx.fxml.FXML;
import javafx.scene.control.Slider;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import java.util.prefs.Preferences;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;

public class SettingsController11 {

    @FXML
    private Slider bgMusicSlider;

    @FXML
    private Slider fxSoundSlider;
    private Preferences prefs;
    private MediaPlayer bgMusicPlayer;
    private MediaPlayer fxSoundPlayer;
    private Stage stage;
    @FXML
    private Button back;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    private void initialize() {
        prefs = Preferences.userNodeForPackage(getClass());
        String bgMusicFile = "/demo/main/background_music.mp3";
        String fxSoundFile = "/demo/main/fx_sound.mp3";

        Media bgMusicMedia = new Media(getClass().getResource(bgMusicFile).toString());
        Media fxSoundMedia = new Media(getClass().getResource(fxSoundFile).toString());

        bgMusicPlayer = new MediaPlayer(bgMusicMedia);
        fxSoundPlayer = new MediaPlayer(fxSoundMedia);

        bgMusicSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            double volume = newValue.doubleValue() / 100.0;
            bgMusicPlayer.setVolume(volume);
            System.out.println("Background Music Volume: " + volume);
        });

        fxSoundSlider.valueProperty().addListener((observable, oldValue, newValue) -> {
            double volume = newValue.doubleValue() / 100.0;
            fxSoundPlayer.setVolume(volume);
            System.out.println("FX Sound Volume: " + volume);
        });

        loadPreferences();
        bgMusicPlayer.play();
        fxSoundPlayer.play();
    }

    private void loadPreferences() {
        double bgVolume = prefs.getDouble("bgMusicVolume", 50.0);
        double fxVolume = prefs.getDouble("fxSoundVolume", 50.0);

        bgMusicSlider.setValue(bgVolume);
        fxSoundSlider.setValue(fxVolume);

        bgMusicPlayer.setVolume(bgVolume / 100.0);
        fxSoundPlayer.setVolume(fxVolume / 100.0);
    }

    private void stop() {
        prefs.putDouble("bgMusicVolume", bgMusicSlider.getValue());
        prefs.putDouble("fxSoundVolume", fxSoundSlider.getValue());

        bgMusicPlayer.stop();
        fxSoundPlayer.stop();
    }

    private void handleBack() {
        stage.close();
    }

    @FXML
    private void Back(ActionEvent event) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("Game.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
}
