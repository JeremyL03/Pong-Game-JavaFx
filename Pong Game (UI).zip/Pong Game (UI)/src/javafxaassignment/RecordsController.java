package javafxaassignment;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;


public class RecordsController {
    @FXML
    private TextField OnePlayerRecord;

    @FXML
    private TextField TwoPlayerRecord;


}
