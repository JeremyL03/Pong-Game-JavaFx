package javafxaassignment;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class ResultsController implements Initializable {
    
    @FXML
    private Text winnerText;
    
    @FXML
    private ImageView backgroundImage;
    
    @FXML
    private ImageView trophyImage;
    
    @FXML
    private Button playAgainButton;
    
    @FXML
    private Button mainMenuButton;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }    
    
    @FXML
    private void handlePlayAgainAction(ActionEvent event) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("Game.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    private void handleMainMenuAction(ActionEvent event) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("MainMenuLogin.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
    public void setWinner(String winner) {
        winnerText.setText(winner + " WINS!");
    }
    
    private void displayImage(){
        Image trophy = new Image(getClass().getResourceAsStream("winnertrophy.png"));
        trophyImage.setImage(trophy);
    }
    
    private void displayImage2(){
        Image background = new Image(getClass().getResourceAsStream("spacebackground.jpg"));
        backgroundImage.setImage(background);
    }
            
    

    @FXML
    private void Menubtn(ActionEvent event) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("MainMenuLogin.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    
}
