/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package javafxaassignment;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.stage.Stage;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author hobot
 */
public class MainMenuController implements Initializable {

    @FXML
    private Button Profile_ID;
    @FXML
    private Button X_ID;
    
    
    
    Stage stage;
    @FXML
    private AnchorPane Mainmenu_ID;
    @FXML
    private Button Signout_ID;
    @FXML
    private Button plays2;
    @FXML
    private Button settings2;
    @FXML
    private Button htp2;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void Signoutbtn(ActionEvent event) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("MainScreen.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
    }


    @FXML
    private void Playbtn(ActionEvent event) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("Game_1.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void xbtn(ActionEvent event) 
    {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("DIEEE");
        alert.setHeaderText("You're about to die!");
        alert.setContentText("Do you want to die before saving?:");
        
        if(alert.showAndWait().get()== ButtonType.OK)
        {
        stage = (Stage) Mainmenu_ID.getScene().getWindow();
        stage.close();
    }
    }

    @FXML
    private void Profilebtn(ActionEvent event) {
    }

    @FXML
    private void settings2(ActionEvent event) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("settings_1.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void htp2(ActionEvent event) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("HowToPlay_1.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

}
    
    

