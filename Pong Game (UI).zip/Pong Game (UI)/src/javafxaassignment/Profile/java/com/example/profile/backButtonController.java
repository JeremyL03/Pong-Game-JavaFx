package javafxaassignment.Profile.java.com.example.profile;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.scene.control.TextField;

public class backButtonController implements Initializable {

    @FXML
    private Button backButton;
    @FXML
    private TextField EmailTextField;
    @FXML
    private TextField usernameTextField;



    public void handleButtonAction(ActionEvent actionEvent) {

        //add action for button
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

}
