/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package javafxapplication1;

import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

public class Score extends Text {

    private int left = 0;
    private int right = 0;

    public Score() {
        super(360, 50, "0 : 0");
        setFont(Font.font(30));
        setFill(Color.WHITE);
    }

    public void addLeft() {
        left++;
        updateText();
    }

    public void addRight() {
        right++;
        updateText();
    }

    private void updateText() {
        setText(left + " : " + right);
    }
}