/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javafxapplication1;

import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class Paddle extends Rectangle {

    private boolean up, down;

    public Paddle(double x, double y, double w, double h) {
        super(x, y, w, h);
        setFill(Color.WHITE);
    }

    public void move() {
        if (up && getY() > 0) setY(getY() - 5);
        if (down && getY() < 600 - getHeight()) setY(getY() + 5);
    }

    public void setUp(boolean up) {
        this.up = up;
    }

    public void setDown(boolean down) {
        this.down = down;
    }
    
}

