/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javafxapplication1;


import javafx.animation.AnimationTimer;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;

public class GamePane extends Pane {

    private Ball ball;
    private Paddle leftPaddle, rightPaddle;
    private Score score;
    private AnimationTimer timer;

    public GamePane() {
        setStyle("-fx-background-color: black;");

        ball = new Ball(400, 300, 10);
        leftPaddle = new Paddle(30, 250, 10, 100);
        rightPaddle = new Paddle(760, 250, 10, 100);
        score = new Score();

        getChildren().addAll(ball, leftPaddle, rightPaddle, score);

        // Keyboard controls
        setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.W) leftPaddle.setUp(true);
            if (e.getCode() == KeyCode.S) leftPaddle.setDown(true);
            if (e.getCode() == KeyCode.UP) rightPaddle.setUp(true);
            if (e.getCode() == KeyCode.DOWN) rightPaddle.setDown(true);
        });

        setOnKeyReleased(e -> {
            if (e.getCode() == KeyCode.W) leftPaddle.setUp(false);
            if (e.getCode() == KeyCode.S) leftPaddle.setDown(false);
            if (e.getCode() == KeyCode.UP) rightPaddle.setUp(false);
            if (e.getCode() == KeyCode.DOWN) rightPaddle.setDown(false);
        });

        setFocusTraversable(true);
    }

    public void startGame() {
        timer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                update();
            }
        };
        timer.start();
    }

    private void update() {
        ball.move();
        leftPaddle.move();
        rightPaddle.move();

        // Collisions with paddles
        if (ball.getBoundsInParent().intersects(leftPaddle.getBoundsInParent()) ||
            ball.getBoundsInParent().intersects(rightPaddle.getBoundsInParent())) {
            ball.reverseX();
        }

        // Top/bottom wall bounce
        if (ball.getCenterY() <= 0 || ball.getCenterY() >= getHeight()) {
            ball.reverseY();
        }

        // Scoring
        if (ball.getCenterX() <= 0) {
            score.addRight();
            ball.reset();
        } else if (ball.getCenterX() >= getWidth()) {
            score.addLeft();
            ball.reset();
        }
    }
}