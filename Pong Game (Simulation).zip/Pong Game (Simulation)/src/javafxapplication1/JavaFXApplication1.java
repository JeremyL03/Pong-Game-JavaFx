/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMain.java to edit this template
 */
package javafxapplication1;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class JavaFXApplication1 extends Application {

    @Override
    public void start(Stage primaryStage) {
        GamePane root = new GamePane();
        Scene scene = new Scene(root, 800, 600);

        primaryStage.setTitle("Pong Game");
        primaryStage.setScene(scene);
        primaryStage.show();

        root.requestFocus();   // 👈 VERY IMPORTANT
        root.startGame();
    }

    public static void main(String[] args) {
        launch(args);
    }
}