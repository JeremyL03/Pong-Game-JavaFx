/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


package javafxapplication1;

import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class Ball extends Circle {

    private double dx;
    private double dy;
    private double speed = 2;             // starting speed
    private final double SPEED_STEP = 0.3; // how much speed increases after paddle hit
    private final double MAX_SPEED = 8;    // safety cap

    public Ball(double x, double y, double r) {
        super(x, y, r);
        setFill(Color.WHITE);
        reset();
    }

    public void move() {
        setCenterX(getCenterX() + dx);
        setCenterY(getCenterY() + dy);
    }

    public void reverseX() {
        dx *= -1;        // flip direction
        increaseSpeed(); // speed up after paddle hit
    }

    public void reverseY() {
        dy *= -1;        // just bounce vertically
    }

    public void reset() {
        setCenterX(400);
        setCenterY(300);

        speed = 2; // reset speed

        // pick random direction but apply speed
        dx = (Math.random() > 0.5 ? 1 : -1) * speed;
        dy = (Math.random() > 0.5 ? 1 : -1) * speed;
    }

    private void increaseSpeed() {
        if (speed < MAX_SPEED) {
            speed += SPEED_STEP;

            // preserve direction while applying new speed
            dx = (dx > 0 ? 1 : -1) * speed;
            dy = (dy > 0 ? 1 : -1) * speed;
        }
    }
}